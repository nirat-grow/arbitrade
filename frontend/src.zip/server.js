import { WebSocketServer } from 'ws';
const wss = new WebSocketServer({ port: 8081 });

console.log("WebSocket server starting on ws://localhost:8081");

function generateData() {
    return [
        { 
            id: 1, 
            type: 'Triangular', 
            network: 'Ethereum', 
            timeLabel: '95S',
            routePath: ['USDC', 'USDT', 'WETH', 'USDC'], 
            calculation: {
                start: '1000.000000',
                final: (990 + Math.random() * 10).toFixed(6),
                gross: (-5 + Math.random() * 2).toFixed(6),
                flashFee: '0.500000',
                gasUsd: '$0.139784',
                net: (-6 + Math.random() * 2).toFixed(6),
                roi: (-0.6 + Math.random() * 0.2).toFixed(4) + '%'
            },
            hops: [
                { dex: 'Uniswap', feeLabel: 'V3 • FEE 100', swapText: 'USDC...USDC → USDT...USDT', router: '0xE592...1564', quoter: '0x61ff...B21e' },
                { dex: 'Uniswap', feeLabel: 'V3 • FEE 3000', swapText: 'USDT...USDT → WETH...WETH', router: '0xE592...1564', quoter: '0x61ff...B21e' },
                { dex: 'Uniswap_500', feeLabel: 'V3 • FEE 500', swapText: 'WETH...WETH → USDC...USDC', router: '0xE592...1564', quoter: '0x61ff...B21e' }
            ]
        },
        { 
            id: 2, 
            type: 'Same-pair', 
            network: 'Polygon', 
            timeLabel: '42S',
            routePath: ['WBTC', 'USDC', 'WBTC'], 
            calculation: {
                start: '23672.18000',
                final: (23900 + Math.random() * 100).toFixed(5),
                gross: (12 + Math.random() * 5).toFixed(5),
                flashFee: '0.000000',
                gasUsd: '$0.021000',
                net: (12 + Math.random() * 5).toFixed(5),
                roi: '+1.5500%'
            },
            hops: [
                { dex: 'QuickSwap', feeLabel: 'V3 • FEE 500', swapText: 'WBTC...WBTC → USDC...USDC', router: '0xa5E0...1234', quoter: '0x12ff...C45a' },
                { dex: 'Uniswap V3', feeLabel: 'V3 • FEE 3000', swapText: 'USDC...USDC → WBTC...WBTC', router: '0xE592...1564', quoter: '0x61ff...B21e' }
            ]
        },
        { 
            id: 3, 
            type: 'Same-pair', 
            network: 'Ethereum', 
            timeLabel: '12S',
            routePath: ['USDC', 'DAI', 'USDC'], 
            calculation: {
                start: '18762.80000',
                final: (18934.9 + Math.random() * 5).toFixed(5),
                gross: (15.2 + Math.random() * 2).toFixed(6),
                flashFee: '2.000000',
                gasUsd: '$4.120000',
                net: (9.1 + Math.random() * 2).toFixed(6),
                roi: `+0.${(8421 + Math.floor(Math.random() * 100))}%`
            },
            hops: [
                { dex: 'Curve', feeLabel: 'V2 • POOL', swapText: 'USDC...USDC → DAI...DAI', router: '0x0000...0000', quoter: '0x0000...0000' },
                { dex: 'Uniswap V3', feeLabel: 'V3 • FEE 100', swapText: 'DAI...DAI → USDC...USDC', router: '0xE592...1564', quoter: '0x61ff...B21e' }
            ]
        },
        { 
            id: 4, 
            type: 'Triangular', 
            network: 'BNB', 
            timeLabel: '14S',
            routePath: ['BNB', 'BUSD', 'CAKE', 'BNB'], 
            calculation: {
                start: '10.500000',
                final: (10.6 + Math.random() * 0.1).toFixed(6),
                gross: (0.1 + Math.random() * 0.05).toFixed(6),
                flashFee: '0.005000',
                gasUsd: '$0.021000',
                net: (0.09 + Math.random() * 0.05).toFixed(6),
                roi: '+0.8500%'
            },
            hops: [
                { dex: 'PancakeSwap', feeLabel: 'V2 • POOL', swapText: 'BNB...BNB → BUSD...BUSD', router: '0x10ED...39b2', quoter: '0x10ED...39b2' },
                { dex: 'Biswap', feeLabel: 'V2 • POOL', swapText: 'BUSD...BUSD → CAKE...CAKE', router: '0x3a6d...f389', quoter: '0x3a6d...f389' },
                { dex: 'PancakeSwap', feeLabel: 'V3 • FEE 2500', swapText: 'CAKE...CAKE → BNB...BNB', router: '0x10ED...39b2', quoter: '0x13f4...24d5' }
            ]
        },
        { 
            id: 5, 
            type: 'Same-pair', 
            network: 'Arbitrum', 
            timeLabel: '2S',
            routePath: ['USDT', 'USDC', 'USDT'], 
            calculation: {
                start: '5000.000000',
                final: (5001.2 + Math.random() * 0.5).toFixed(6),
                gross: (1.2 + Math.random() * 0.2).toFixed(6),
                flashFee: '0.050000',
                gasUsd: '$0.008000',
                net: (1.14 + Math.random() * 0.2).toFixed(6),
                roi: `+0.${(228 + Math.floor(Math.random() * 20))}%`
            },
            hops: [
                { dex: 'Camelot', feeLabel: 'V2 • POOL', swapText: 'USDT...USDT → USDC...USDC', router: '0xc873...192a', quoter: '0xc873...192a' },
                { dex: 'SushiSwap', feeLabel: 'V3 • FEE 500', swapText: 'USDC...USDC → USDT...USDT', router: '0x1b02...c54a', quoter: '0x1b02...c54a' }
            ]
        }
    ];
}

wss.on('connection', (ws) => {
    console.log('Client connected');
    
    // Send initial data immediately
    ws.send(JSON.stringify(generateData()));

    // Broadcast new data every 2 seconds
    const interval = setInterval(() => {
        if (ws.readyState === WebSocket.OPEN) {
            ws.send(JSON.stringify(generateData()));
        }
    }, 2000);

    ws.on('close', () => {
        console.log('Client disconnected');
        clearInterval(interval);
    });
});
