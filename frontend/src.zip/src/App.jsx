import React, { useState, useEffect } from 'react';

const Navbar = () => (
    <nav className="navbar">
        <div className="navbar-content">
            <div className="nav-left">
                <div className="logo-container">
                    <div className="logo-icon"></div>
                    KAROMETA
                </div>
                <div className="nav-links">
                    <a href="#" className="active">Scanner</a>
                    <a href="#">Watchlist <span>8</span></a>
                    <a href="#">Activity</a>
                </div>
            </div>
            <div className="nav-right">
                <div className="status-pill">
                    <div className="live-feed-indicator">
                        <div className="live-dot"></div>
                        Live feed
                    </div>
                    <div className="status-divider"></div>
                    <div className="bell-icon">🔔</div>
                </div>
            </div>
        </div>
    </nav>
);

const Header = ({ syncTime }) => {
    const formattedTime = syncTime.toLocaleTimeString('en-US', { hour12: false, timeZone: 'UTC' });
    
    return (
        <div className="header-section">
            <div className="header-title-area">
                <div className="observatory-label">— OBSERVATORY / 04</div>
                <h1 className="main-heading">
                    <div className="heading-line1">Arbitrage</div>
                    <div className="heading-line2">signal array</div>
                </h1>
                <p className="sub-heading">Cross-venue price intelligence for fast, disciplined execution.</p>
            </div>
            <div className="sync-area">
                <div className="sync-label">LAST SYNC</div>
                <div className="sync-time">{formattedTime}</div>
                <div className="sync-block">UTC - block 19,842,106</div>
            </div>
        </div>
    );
};

const SignalEqualizer = ({ segmentsCount = 11 }) => {
    // Generate an array of segments with varying sizes for the scanner
    const segments = [...Array(segmentsCount)].map((_, i) => {
        const delay = i * 0.15; // Smooth sequential delay left to right
        const baseFlex = 2 + Math.random() * 2; // Only large blocks of slightly different widths
        return { id: i, delay, baseFlex };
    });

    return (
        <div className="signal-bar-container">
            <div className="signal-bar-label">
                <div className="signal-bar-dot"></div>
                SCANNER SIGNAL STRENGTH
            </div>
            <div className="equalizer-segments">
                {segments.map((seg) => (
                    <div 
                        key={seg.id} 
                        className="eq-segment scan-pulse" 
                        style={{ 
                            flex: seg.baseFlex,
                            animationDelay: `${seg.delay}s`
                        }}
                    ></div>
                ))}
            </div>
            <div className="signal-bar-value">
                87.4% <span className="signal-bar-status">stable array</span>
            </div>
        </div>
    );
};

const useCountUp = (endValueStr, duration, isExpanded, delay = 250) => {
    const [displayValue, setDisplayValue] = useState('0' + (endValueStr.includes('.') ? '.'.padEnd(endValueStr.split('.')[1]?.length + 2, '0') : ''));
    const [hasAnimated, setHasAnimated] = useState(false);

    useEffect(() => {
        if (!isExpanded) {
            let resetZero = '0';
            if (endValueStr.includes('.')) {
                resetZero = '0.' + '0'.repeat(endValueStr.split('.')[1].length);
            }
            if (endValueStr.includes('$')) resetZero = '$' + resetZero;
            if (endValueStr.includes('%')) resetZero = resetZero + '%';
            if (endValueStr.startsWith('-')) resetZero = '-' + resetZero;
            
            setDisplayValue(resetZero);
            setHasAnimated(false);
            return;
        }
        
        if (hasAnimated) {
            setDisplayValue(endValueStr);
            return;
        }

        const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
        if (prefersReducedMotion) {
            setDisplayValue(endValueStr);
            setHasAnimated(true);
            return;
        }

        let isNegative = endValueStr.startsWith('-');
        let isCurrency = endValueStr.includes('$');
        let isPercentage = endValueStr.includes('%');
        let rawStr = endValueStr.replace(/[-$%]/g, '');
        let targetNum = parseFloat(rawStr);
        if (isNaN(targetNum)) {
            setDisplayValue(endValueStr);
            setHasAnimated(true);
            return;
        }

        let decimalPlaces = 0;
        if (rawStr.includes('.')) {
            decimalPlaces = rawStr.split('.')[1].length;
        }

        let startTime = null;
        let animationFrame;

        const animate = (timestamp) => {
            if (!startTime) startTime = timestamp;
            const progress = timestamp - startTime;
            const percentage = Math.min(progress / duration, 1);
            
            const easeOut = 1 - Math.pow(1 - percentage, 3);
            const currentNum = targetNum * easeOut;

            let formatted = currentNum.toFixed(decimalPlaces);
            if (isCurrency) formatted = '$' + formatted;
            if (isNegative) formatted = '-' + formatted;
            if (isPercentage) formatted = formatted + '%';

            setDisplayValue(formatted);

            if (percentage < 1) {
                animationFrame = requestAnimationFrame(animate);
            } else {
                setDisplayValue(endValueStr);
                setHasAnimated(true);
            }
        };

        const delayTimeout = setTimeout(() => {
            animationFrame = requestAnimationFrame(animate);
        }, delay);

        return () => {
            clearTimeout(delayTimeout);
            if (animationFrame) cancelAnimationFrame(animationFrame);
        };
    }, [endValueStr, duration, isExpanded, hasAnimated]);

    if (!isExpanded && displayValue !== endValueStr && !displayValue.startsWith('0') && !displayValue.startsWith('-0') && !displayValue.startsWith('$0')) {
         return endValueStr; 
    }

    return displayValue;
};

const AnimatedCalcItem = ({ label, valueStr, valueColorClass, isExpanded, isNetRow = false }) => {
    const animatedValue = useCountUp(valueStr, 500, isExpanded, 50); // Start soon after panel fade
    
    if (isNetRow) {
        return (
            <div className="calc-item net-row">
                <span className="c-label">{label}</span>
                <span className={`c-val net-val tabular-nums ${valueStr.startsWith('-') ? 'danger-text' : 'success-text'}`}>
                    {animatedValue}
                </span>
            </div>
        );
    }

    return (
        <div className="calc-item">
            <span className="c-label">{label}</span>
            <span className={`c-val ${valueColorClass} tabular-nums`}>{animatedValue}</span>
        </div>
    );
};

const CopyableAddress = ({ address }) => {
    const [copied, setCopied] = useState(false);

    const handleCopy = (e) => {
        e.stopPropagation();
        navigator.clipboard.writeText(address);
        setCopied(true);
        setTimeout(() => setCopied(false), 1200);
    };

    return (
        <span className={`a-val copyable ${copied ? 'is-copied' : ''}`} onClick={handleCopy} title="Copy to clipboard">
            {address} <span className="copy-icon">{copied ? '✓ Copied' : '⎘'}</span>
        </span>
    );
};

const CircleChart = ({ score, isExpanded }) => {
    const radius = 36;
    const circumference = 2 * Math.PI * radius;
    const strokeDashoffset = circumference - (score / 100) * circumference;

    return (
        <div className={`circle-chart-container ${isExpanded ? 'animate' : ''}`}>
            <svg width="100" height="100" viewBox="0 0 100 100">
                <circle className="circle-bg" cx="50" cy="50" r={radius} />
                <circle 
                    className="circle-progress" 
                    cx="50" cy="50" r={radius} 
                    style={{
                        strokeDasharray: circumference,
                        strokeDashoffset: isExpanded ? strokeDashoffset : circumference,
                    }} 
                />
            </svg>
            <div className="circle-text">
                <div className="circle-score tabular-nums">{useCountUp(`${score}%`, 1200, isExpanded, 200)}</div>
                <div className="circle-label">MATCH</div>
            </div>
        </div>
    );
};

const FlashValue = ({ value, className, style }) => {
    const [flash, setFlash] = useState(false);
    const [prevValue, setPrevValue] = useState(value);

    useEffect(() => {
        if (value !== prevValue) {
            setFlash(true);
            setPrevValue(value);
            const timer = setTimeout(() => setFlash(false), 500);
            return () => clearTimeout(timer);
        }
    }, [value, prevValue]);

    return (
        <span className={`${className} mono-num flash-value ${flash ? 'is-flashing' : ''}`} style={style}>
            {value}
        </span>
    );
};

const SignalRow = ({ data }) => {
    const [isExpanded, setIsExpanded] = useState(false);

    // Prevent crash if backend still sending old data format
    if (!data.calculation) return null;

    return (
        <div className={`table-row-container ${isExpanded ? 'expanded' : ''}`}>
            {/* The always-visible summary row */}
            <div className="table-row-summary" onClick={() => setIsExpanded(!isExpanded)}>
                <div className="t-col col-network">
                    <div className="network-name">
                        <span className="net-dot"></span> {data.network.toUpperCase()}
                    </div>
                </div>
                <div className="t-col col-route">
                    <div className="new-route-title" style={{fontSize: '0.9rem', marginBottom: '6px'}}>
                        <span className="icon-chip" style={{fontSize: '1rem'}}>🖧</span> 
                        {data.routePath.map((node, i) => (
                            <React.Fragment key={i}>
                                <span className="route-coin">{node}</span>
                                {i < data.routePath.length - 1 && <span className="route-arrow">→</span>}
                            </React.Fragment>
                        ))}
                    </div>
                    <div className={`type-badge badge-${data.type.toLowerCase().replace(/\s+/g, '-')}`}>{data.type.toUpperCase()}</div>
                </div>
                <div className="t-col col-time">
                    <div className="timer-badge" style={{width: 'max-content'}}>
                        <span className="timer-icon">🕒</span> {data.timeLabel}
                    </div>
                </div>
                <div className="t-col col-net">
                    <FlashValue 
                        className={`c-val ${data.calculation.net.startsWith('-') ? 'danger-text' : 'success-text'}`} 
                        style={{fontSize: '1.1rem'}}
                        value={data.calculation.net} 
                    />
                </div>
                <div className="t-col col-roi">
                    <div className="roi-wrapper">
                        {(() => {
                            const roiVal = parseFloat(data.calculation.roi);
                            const absRoi = Math.abs(roiVal);
                            const h1 = Math.min(6, Math.max(2, absRoi * 2));
                            const h2 = Math.min(10, Math.max(4, absRoi * 4));
                            const h3 = Math.min(14, Math.max(6, absRoi * 6));
                            const h4 = Math.min(18, Math.max(8, absRoi * 8));
                            const colorClass = roiVal < 0 ? 'danger-text' : 'success-text';
                            return (
                                <div className="mini-chart">
                                    <div className="mc-bar" style={{height: `${h1}px`}}></div>
                                    <div className="mc-bar" style={{height: `${h2}px`}}></div>
                                    <div className="mc-bar" style={{height: `${h3}px`}}></div>
                                    <div className={`mc-bar glow-bar ${colorClass}`} style={{height: `${h4}px`}}></div>
                                </div>
                            );
                        })()}
                        <FlashValue 
                            className={`c-val ${data.calculation.roi.startsWith('-') ? 'danger-text' : 'success-text'}`} 
                            style={{fontSize: '1.1rem'}}
                            value={data.calculation.roi} 
                        />
                    </div>
                </div>
                <div className="t-col col-action">
                    <button className="expand-btn">
                        <span className={`chevron-icon ${isExpanded ? 'rotated' : ''}`}>▼</span>
                    </button>
                </div>
            </div>

            {/* Expandable Details Content */}
            <div className="table-row-details">
                <div className="details-content">
                    {/* Calculation Summary */}
                    <div className="inner-box calc-summary">
                        <div className="box-title"><span className="info-icon">◐</span> CALCULATION SUMMARY</div>
                        <div className="calc-list">
                            <AnimatedCalcItem label="Start" valueStr={data.calculation.start} valueColorClass="white" isExpanded={isExpanded} />
                            <AnimatedCalcItem label="Gross" valueStr={data.calculation.gross} valueColorClass="cyan" isExpanded={isExpanded} />
                            <AnimatedCalcItem label="Gas USD" valueStr={data.calculation.gasUsd} valueColorClass="purple" isExpanded={isExpanded} />
                            <AnimatedCalcItem label="Final" valueStr={data.calculation.final} valueColorClass="white" isExpanded={isExpanded} />
                            <AnimatedCalcItem label="Flash Fee" valueStr={data.calculation.flashFee} valueColorClass="yellow" isExpanded={isExpanded} />
                            <AnimatedCalcItem label="Net" valueStr={data.calculation.net} isExpanded={isExpanded} isNetRow={true} />
                        </div>
                        
                        <div className="chart-fill-space">
                            <CircleChart score={87} isExpanded={isExpanded} />
                            <div className="chart-fill-info">
                                <div className="cfi-title">AI Signal Confidence</div>
                                <div className="cfi-desc">High probability based on historical spread volatility. Executing sequence...</div>
                            </div>
                        </div>
                    </div>

                    {/* Route / Router / Quoter */}
                    <div className="inner-box route-breakdown">
                        <div className="box-title"><span className="layers-icon">◆</span> ROUTE / ROUTER / QUOTER</div>
                        <div className="timeline-container" style={{ '--draw-duration': `${500 + (data.hops.length * 600)}ms` }}>
                            {data.hops.map((hop, index) => {
                                const drawDuration = (500 + (data.hops.length * 600)) / 1000;
                                const beamHitTime = (index / Math.max(1, data.hops.length - 1)) * 3;
                                const totalFlashDelay = drawDuration + 0.2 + beamHitTime;
                                return (
                                <div className="hop-item" key={index} style={{ '--flash-delay': `${totalFlashDelay}s` }}>
                                    <div className="hop-marker"></div>
                                    <div className="hop-content">
                                        <div className="hop-header">
                                            <span className="hop-dex badge-dex">{hop.dex}</span>
                                            <span className="hop-fee badge-fee">{hop.feeLabel}</span>
                                        </div>
                                        <div className="hop-swap">{hop.swapText}</div>
                                        <div className="hop-address">
                                            <span className="a-label">Router</span>
                                            <CopyableAddress address={hop.router} />
                                        </div>
                                        <div className="hop-address">
                                            <span className="a-label">Quoter</span>
                                            <CopyableAddress address={hop.quoter} />
                                        </div>
                                    </div>
                                </div>
                                );
                            })}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

const App = () => {
    const [signals, setSignals] = useState([]);
    const [syncTime, setSyncTime] = useState(new Date());
    const [filter, setFilter] = useState('All networks');
    const [isRescanning, setIsRescanning] = useState(false);

    const handleRescan = () => {
        setIsRescanning(true);
        setTimeout(() => setIsRescanning(false), 500);
    };

    useEffect(() => {
        let ws;
        let reconnectTimer;

        const connect = () => {
            const urlParams = new URLSearchParams(window.location.search);
            const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
            const backendUrl = urlParams.get('backend') || `${protocol}//${window.location.host}/ws`;
            ws = new WebSocket(backendUrl);
            
            ws.onopen = () => {
                console.log('Connected to server');
            };

            ws.onmessage = (event) => {
                const data = JSON.parse(event.data);
                setSignals(data);
                setSyncTime(new Date());
            };

            ws.onclose = () => {
                console.log('Disconnected, reconnecting in 2s...');
                reconnectTimer = setTimeout(connect, 2000);
            };
            
            ws.onerror = (err) => {
                console.error('WebSocket Error:', err);
            };
        };

        connect();

        return () => {
            if (ws) ws.close();
            clearTimeout(reconnectTimer);
        };
    }, []);

    const filteredSignals = filter === 'All networks' 
        ? signals 
        : signals.filter(s => s.network === filter);

    return (
        <div>
            <Navbar />
            <div className="container">
                <Header syncTime={syncTime} />
                <SignalEqualizer segmentsCount={16} />
                
                <div className="controls-section">
                    <div className="controls-left">
                        <div className="opportunity-label">
                            <span className="opportunity-icon">⎈</span> Opportunity field <span className="signals-count">{filteredSignals.length} signals in range</span>
                        </div>
                        <div className="filters">
                            <button className={`filter-btn ${filter === 'All networks' ? 'active btn-all' : ''}`} onClick={() => setFilter('All networks')}>
                                <span className="network-dot dot-all"></span> All networks
                            </button>
                            <button className={`filter-btn ${filter === 'Polygon' ? 'active btn-polygon' : ''}`} onClick={() => setFilter('Polygon')}>
                                <span className="network-dot dot-polygon"></span> Polygon
                            </button>
                            <button className={`filter-btn ${filter === 'Ethereum' ? 'active btn-ethereum' : ''}`} onClick={() => setFilter('Ethereum')}>
                                <span className="network-dot dot-ethereum"></span> Ethereum
                            </button>
                            <button className={`filter-btn ${filter === 'BNB' ? 'active btn-bnb' : ''}`} onClick={() => setFilter('BNB')}>
                                <span className="network-dot dot-bnb"></span> BNB
                            </button>
                        </div>
                    </div>
                    
                    <div className="search-rescan">
                        <div className="search-box">
                            <span className="search-icon">
                                <svg viewBox="0 0 24 24">
                                    <path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/>
                                </svg>
                            </span>
                            <input type="text" placeholder="Search pair or venue" />
                        </div>
                        <button className="rescan-btn" onClick={handleRescan}>
                            <span className={`rescan-icon ${isRescanning ? 'spin' : ''}`}>⟳</span> Re-scan
                        </button>
                    </div>
                </div>

                <div className="signals-table-container">
                    <div className="table-header">
                        <div className="t-col col-network">NETWORK</div>
                        <div className="t-col col-route">ROUTE / TYPE</div>
                        <div className="t-col col-time">TIME</div>
                        <div className="t-col col-net">NET PROFIT</div>
                        <div className="t-col col-roi">EST. ROI</div>
                        <div className="t-col col-action"></div>
                    </div>
                    <div className="signals-table-body">
                        {filteredSignals.map(signal => (
                            <SignalRow key={signal.id} data={signal} />
                        ))}
                    </div>
                </div>
                
                <div className="footer-bar">
                    <div className="footer-left">
                        <span className="footer-dot"></span> Data refreshed every 15 seconds
                    </div>
                    <div className="footer-right">
                        KAROMETA INTELLIGENCE <span className="footer-separator">•</span> PAPER MODE
                    </div>
                </div>
            </div>
        </div>
    );
};

export default App;
